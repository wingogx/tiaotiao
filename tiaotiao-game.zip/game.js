import Main from './js/main.js';

// 创建游戏实例
new Main();